#########################################
		Readme - Milestone 3
#########################################

--Autoren--
Andr� Burg
Luis Hohmann
Chantal Klemm
Arvin Matics

--

--Einf�hrung--
Vorliegender Ordner ist ein QT Projekt, welches durch �ffnen der .pro-Datei in Qt Creator ausgef�hrt werden kann.

--

--Bestehende Probleme zum Zeitpunkt der Abgabe--

- J�ger bewegen sich nicht weiter, wenn sie auf benachbarte J�ger oder Futter sto�en
- Gejagte bewegen sich nicht weiter, wenn sie auf benachbarte Gejagte sto�en
- Bewegung geschieht nur horizontal oder vertikal
- Nachbarschaftsverh�ltnisse werden nur horizontal oder vertikal gepr�ft


Die Aufgabenstellung suggerierte eine Implementierung von Hunter mittels CAbase.
In dieser Version wurde Hunter jedoch unabh�ngig von CAbase implementiert.

F�r die Implementierung von Hunter sind somit nur hunter.h, sowie die
entsprechend kommentierten Anpassungen in gamewidget.h/.cpp und mainwindow.h/.cpp relevant.

