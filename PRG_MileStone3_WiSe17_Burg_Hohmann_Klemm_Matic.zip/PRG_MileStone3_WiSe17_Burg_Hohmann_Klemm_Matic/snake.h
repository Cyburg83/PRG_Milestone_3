#ifndef SNAKE_H
#define SNAKE_H

#include <iostream>

class Snake

{
private:
    struct Segment  // data structure linked list for head, body, tail
    {
        int coords;
        Segment *next;
    };

    Segment *head;
    Segment *tail;

    int gridSize;   // needed for wall collision
    int currDirection;
    int snakeSize;
    bool food;      // handles food generation
    int foodCoords;
    int lastTailPos;    // stores coordinates for appending new segment when eating


    void append(int xCoord, int yCoord);
    void updateCoords(Segment *current, int newCoords);
    void wallCollision();
    void snakeCollision();
    bool fieldIsSnake(int coords);
    void setFood();
    void eatFood();


public:
    Snake() // constructor
        // initialization list
        : gridSize(30)
        , currDirection(6)
        , snakeSize(0)
        , food(false)
        , foodCoords(-1)
        , lastTailPos(-1)
        , dead(false)
    {
        head = NULL;
        tail = NULL;
    }

    ~Snake();

    bool dead;  // public for gamewidget

    void setup();
    void reset();
    int* getSnakeCoords();
    int getsnakeSize() { return snakeSize; }
    int getLastTailPos() { return lastTailPos; }
    void print();
    void evolveSnake();
    void steerSnake(int newDirection);
    int getHead() { return head->coords; }
    int getFoodCoords() { return foodCoords; }


};


inline void Snake::append(int xCoord, int yCoord)
{
    // append new segment to snake (that will become its tail)
    Segment *newTail = new Segment;
    int newCoords = xCoord + gridSize*yCoord;
    newTail->coords = newCoords;
    newTail->next = NULL;

    if(head == NULL) {
        tail = head = newTail;
        newTail = NULL;
    }
    else {
        tail->next = newTail;
        tail = newTail;
    }
    snakeSize++;
}

inline void Snake::reset()
{
    //deletes all Segments
    Segment *current = new Segment;
    current = head;

    while (current != NULL) {

        Segment *temp = current->next;
        delete[] current;
        current = temp;
    }
    snakeSize = 0;
}

inline void Snake::setup()
{
    // initial board setup
    append(2,2);
    append(1,2);
    append(0,2);
    append(0,3);
    append(0,4);
    append(0,5);
    append(0,6);
    append(0,7);

    setFood();
}

inline void Snake::print()
{
    // for testing purpose; not needed for widget
    Segment *current = new Segment;
    current = head;

    while (current != NULL) {
        std::cout << current->coords << "\t";
        current = current->next;
    }
    std::cout << std::endl;
}

inline int* Snake::getSnakeCoords()
{
    // returns list of all segment coords that is then passed to gamewidget's paintUniverse
    int* snakeCoords = new int[snakeSize];
    Segment *current = new Segment;
    current = head;
    int index = 0;

    while (current != NULL) {
        snakeCoords[index] = current->coords;
        current = current->next;
        index++;
    }
    return snakeCoords;
}


inline void Snake::updateCoords(Segment *current, int newCoords)
{
    // recursive;
    // head gets new value
    // all current values get successively passed on to next segment
    int tempCoords = current->coords;
    current->coords = newCoords;
    if (current->next != NULL) {
        updateCoords(current->next, tempCoords);
    }
}

inline void Snake::evolveSnake()
{
    // initalizes updateCoords with respective newCoords for head
    // evaluates collision based on current head coords and direction
    // handles eating and growth
    wallCollision();
    snakeCollision();
    eatFood();
    setFood();
    if (!dead) {
        lastTailPos = tail->coords;
        int headPos = head->coords;
        switch (currDirection) {
        case 2:
            updateCoords(head, headPos + gridSize);
            break;
        case 4:
            updateCoords(head, headPos - 1);
            break;
        case 6:
            updateCoords(head, headPos + 1);
            break;
        case 8:
            updateCoords(head, headPos - gridSize);
            break;
        default:
            break;
        }
    }
    else {
        std::cout << "Game Over, Man!" << std::endl;
    }

}

inline void Snake::steerSnake(int newDirection)
{
    // handles direction input (triggered by keyPressEvent)
    switch (newDirection) {
    case 2:
        if(currDirection != 8) {
            currDirection = 2;
        }
        break;
    case 4:
        if (currDirection != 6) {
            currDirection = 4;
        }
        break;
    case 6:
        if (currDirection != 4) {
            currDirection = 6;
        }
        break;
    case 8:
        if (currDirection != 2) {
            currDirection = 8;
        }
        break;
    default:
        break;
    }
}

inline void Snake::wallCollision()
{
    // uses current head position and direction
    int headPos = head->coords;
    switch (currDirection) {
    case 2:
        if (headPos > gridSize*(gridSize-1)-1) { dead = true; }
        break;
    case 4:
        if (headPos%gridSize == 0) { dead = true; }
        break;
    case 6:
        if (headPos%gridSize == gridSize-1) { dead = true; }
        break;
    case 8:
        if (headPos < gridSize) { dead = true; }
        break;
    default:
        dead = false;
        break;
    }
}

inline void Snake::snakeCollision()
{
    // checks for head-body collision
    Segment *current = new Segment;
    current = head->next;
    while (current != NULL) {
        if (current->coords == head->coords) {
            dead = true;
            std::cout << "Game Over, Man!" << std::endl;
            break;
        }
        current = current->next;
    }
}

inline bool Snake::fieldIsSnake(int coords)
{
    // condition for food generation
    Segment *current = new Segment;
    current = head;

    while(current != NULL) {
        if (coords == current->coords){
            return true;
        }
        current = current->next;
    }
    return false;
}


inline void Snake::setFood()
{
    // generats food randomly if none is on board
    if (!food) {
        srand(time(NULL));
        int randomCoords;

        do {
            randomCoords = rand() % (gridSize*gridSize);
        }
        while (fieldIsSnake(randomCoords));

        foodCoords = randomCoords;
        food = true;
    }
}

inline void Snake::eatFood()
{
    // eating and growth
    if (head->coords == foodCoords) {
        int newXCoords = lastTailPos%gridSize;
        int newYCoords = lastTailPos/gridSize;
        append(newXCoords, newYCoords);
        food = false;
    }
}


#endif // SNAKE_H
