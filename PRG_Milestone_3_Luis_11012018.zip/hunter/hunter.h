#ifndef SNAKE_H
#define SNAKE_H

class Hunter{

public:







    Hunter(int Nx, int Ny, int max_lifetime){
        /* - Nx and Ny for grid size
         * - dynamic integer arrays for cell: status, direction, lifetime
         *   (Cell: 0 -> empty, 1 -> hunter, 2 -> hunted, 3 -> food)*/
        _size_x = Nx;
        _size_y = Ny;
        _max_lifetime = max_lifetime;



        _status = new int[_size_x*_size_y];
        _direction = new Position[_size_x*_size_y];
        _lifetime = new int[_size_x*_size_y];

        _clear();
    }

    ~Hunter(){
        delete [] _status;
        delete [] _direction;
        delete [] _lifetime;
    }


    // --- Public Setters ---

    void CellEvolutionDirection(int cell){




        // FEHLT
        // HILFE
        std::cout << "-- Zelle Nr. " << cell << ":" << std::endl;


        // check if cell is alive (hunter or hunted)
        if (_status[cell] == 1 || _status[cell] == 2){

            // HILFE
            std::cout << "Zelle Nr. " << cell << " ist lebendig!" << std::endl;



                // check if cell has neighbors (hunter, hunted, food)
                if (_status[cell + _size_x] || _status[cell - _size_x] || _status[cell - 1] || _status[cell + 1]){

                    // HILFE
                    std::cout << "Zelle Nr. " << cell << " hat Nachbarn!" << std::endl;

                    // check if hunter
                    if (_status[cell] == 1){

                        // HILFE
                        std::cout << "Zelle Nr. " << cell << " ist Jaeger!" << std::endl;

                        // check if hunteds are nearby
                        int number_of_hunteds_nearby = 0;

                        Position nearby_hunteds[4];

                        // check lower cell
                        if (_status[cell + _size_x] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = LOWER;
                            number_of_hunteds_nearby++;
                        }
                        // check upper cell
                        if (_status[cell - _size_x] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = UPPER;
                            number_of_hunteds_nearby++;
                        }
                        // check left cell
                        if (_status[cell - 1] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = LEFT;
                            number_of_hunteds_nearby++;
                        }
                        // check right cell
                        if (_status[cell + 1] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = RIGHT;
                            number_of_hunteds_nearby++;
                        }

                        srand(time(NULL));
                        int random_neighbor = rand() % number_of_hunteds_nearby;

                        Position choosen_neighbor = nearby_hunteds[random_neighbor];

                        switch(choosen_neighbor){
                            // hunt lower hunted
                            case LOWER: _direction[cell] = LOWER; break;
                            // hunt upper hunted
                            case UPPER: _direction[cell] = UPPER; break;
                            // hunt left hunted
                            case LEFT: _direction[cell] = LEFT; break;
                            // hunt right hunted
                            case RIGHT: _direction[cell] = RIGHT; break;
                        }

                    }
                    // check if hunted
                    if (_status[cell] == 2){

                        // HILFE
                        std::cout << "Zelle" << cell << "ist Gejagter!" << std::endl;

                        // check if hunter is not nearby
                        if (!((_status[cell + _size_x] == 1) || (_status[cell - _size_x] == 1) || (_status[cell - 1] == 1)|| (_status[cell + 1] == 1))){

                            // HILFE
                            std::cout << "Kein Jaeger daneben! Suche Futter!" << std::endl;

                            // check if food is nearby
                            int number_of_food = 0;

                            Position food[4];

                            // check lower cell
                            if (_status[cell + _size_x] == 3){
                                food[number_of_food] = LOWER;
                                number_of_food++;

                                // HILFE
                                std::cout << "Pruefe unteren Nachbarn!" << std::endl;
                            }
                            // check upper cell
                            if (_status[cell - _size_x] == 3){
                                food[number_of_food] = UPPER;
                                number_of_food++;

                                // HILFE
                                std::cout << "Pruefe oberen Nachbarn!" << std::endl;
                            }
                            // check left cell
                            if (_status[cell - 1] == 3){
                                food[number_of_food] = LEFT;
                                number_of_food++;

                                // HILFE
                                std::cout << "Pruefe linken Nachbarn!" << std::endl;
                            }
                            // check right cell
                            if (_status[cell + 1] == 3){
                                food[number_of_food] = RIGHT;
                                number_of_food++;

                                // HILFE
                                std::cout << "Pruefe rechten Nachbarn!" << std::endl;
                            }

                            // if food was found
                            if (number_of_food > 0){

                                // HILFE
                                std::cout << "Mind. ein Futter ist Nachbar!" << std::endl;
                                srand(time(NULL));
                                int random_food = rand() % number_of_food;

                                Position choosen_food = food[random_food];

                                switch(choosen_food){
                                    case LOWER: _direction[cell] = LOWER;
                                    // HILFE
                                    std::cout << "Versuche unteren zu fressen!" << std::endl;
                                    break;
                                    case UPPER: _direction[cell] = UPPER;
                                    // HILFE
                                    std::cout << "Versuche oberen zu fressen!" << std::endl;
                                    break;
                                    case LEFT: _direction[cell] = LEFT;
                                    // HILFE
                                    std::cout << "Versuche linken zu fressen!" << std::endl;
                                    break;
                                    case RIGHT: _direction[cell] = RIGHT;
                                    // HILFE
                                    std::cout << "Versuche rechten zu fressen!" << std::endl;
                                    break;
                                }
                            }
                        }
                    }
                }else{ // move cell randomly if it has no neighbors
                    srand(time(NULL));
                    Position random_position = Position(rand()%4);

                    switch(random_position){
                        case LOWER: _direction[cell] = LOWER; break;
                        case UPPER: _direction[cell] = UPPER; break;
                        case LEFT: _direction[cell] = LEFT; break;
                        case RIGHT: _direction[cell] = RIGHT; break;
                    }

                }
        }
    }


    void CellEvolutionMove(int cell){
        // FEHLT


        // check if cell is hunter or hunted
        if ((_status[cell] == 1) || (_status[cell] == 2)){
            _lifetime[cell]--; // decrement lifetime

            // kills cell
            if(_lifetime[cell] <= 0){
                // HILFE
                std::cout << "Zelle stirbt!" << std::endl;
                _status[cell] = 0;
                _lifetime[cell] = 0;
            }    
        }

        // check if cell is food
        if (_status[cell] == 3){
            // HILFE
            std::cout << "Zelle Nr. " << cell << " ist Futter!" << std::endl;

            int number_of_hunted_which_want_food = 0;

            Position hunteds_which_want_food[4];

            // check if lower cell is hunted and want to eat current cell
            if (_status[cell + _size_x] == 2){
                // HILFE
                std::cout << "Untere Zelle von " << cell << " ist Gejagter!" << std::endl;

                if(_direction[cell + _size_x] == UPPER){
                    // HILFE
                    std::cout << "und möchte Zelle über sich fressen!" << std::endl;
                    hunteds_which_want_food[number_of_hunted_which_want_food]=LOWER;
                    number_of_hunted_which_want_food++;
                }
            }
            // check if upper cell is hunted and want to eat current cell
            if (_status[cell - _size_x] == 2){
                // HILFE
                std::cout << "Obere Zelle von " << cell << " ist Gejagter!" << std::endl;

                if(_direction[cell - _size_x] == LOWER){
                    hunteds_which_want_food[number_of_hunted_which_want_food]=UPPER;
                    number_of_hunted_which_want_food++;
                }
            }
            // check if left cell is hunted and want to eat current cell
            if (_status[cell - 1] == 2){
                // HILFE
                std::cout << "Linke Zelle von " << cell << " ist Gejagter!" << std::endl;

                if(_direction[cell - 1] == RIGHT){
                    hunteds_which_want_food[number_of_hunted_which_want_food]=LEFT;
                    number_of_hunted_which_want_food++;
                }
            }
            // check if right cell is hunted and want to eat current cell
            if (_status[cell + 1] == 2){
                // HILFE
                std::cout << "Rechte Zelle von " << cell << " ist Gejagter!" << std::endl;

                if(_direction[cell + 1] == LEFT){
                    hunteds_which_want_food[number_of_hunted_which_want_food]=RIGHT;
                    number_of_hunted_which_want_food++;
                }
            }


            if (number_of_hunted_which_want_food > 0){
                // HILFE
                std::cout << "Mindestens ein Nachbar von " << cell << " möchte es fressen!" << std::endl;

                srand(time(NULL));
                Position eating_hunted = hunteds_which_want_food[rand() % number_of_hunted_which_want_food];

                switch(eating_hunted){
                    case LOWER:
                    // HILFE
                    std::cout << "Futter in Zelle " << cell << " wird von unterem Gejagten gefressen!" << std::endl;
                        _status[cell]=2;
                        _lifetime[cell]=_max_lifetime;

                        _status[cell+_size_x]=0;
                        _lifetime[cell+_size_x]=0;
                    break;
                    case UPPER:
                    // HILFE
                    std::cout << "Futter in Zelle " << cell << " wird von oberem Gejagten gefressen!" << std::endl;
                        _status[cell]=2;
                        _lifetime[cell]=_max_lifetime;

                        _status[cell-_size_x]=0;
                        _lifetime[cell-_size_x]=0;
                    break;
                    case LEFT:
                    // HILFE
                    std::cout << "Futter in Zelle " << cell << " wird von linkem Gejagten gefressen!" << std::endl;
                        _status[cell]=2;
                        _lifetime[cell]=_max_lifetime;

                        _status[cell-1]=0;
                        _lifetime[cell-1]=0;
                    break;
                    case RIGHT:
                    // HILFE
                    std::cout << "Futter in Zelle " << cell << " wird von rechtem Gejagten gefressen!" << std::endl;
                        _status[cell]=2;
                        _lifetime[cell]=_max_lifetime;

                        _status[cell+1]=0;
                        _lifetime[cell+1]=0;
                    break;
                }
            }

        }


    }



    void WorldEvolutionLifePredator(){
        for(int i = 0; i < _size_x * _size_y; i++){
            CellEvolutionDirection(i); 
        }
        for(int i = 0; i < _size_x * _size_y; i++){
            CellEvolutionMove(i);
        }
    }

    void setLifetime(int lifetime){
        _max_lifetime = lifetime;
    }

    void setHunter(int cell){
        if((0 <= cell) &&  (cell <= (_size_x*_size_y))){
            _status[cell] = 1;
            _lifetime[cell] = _max_lifetime;
        }
    }

    void setHunted(int cell){
        if((0 <= cell) &&  (cell <= (_size_x*_size_y))){
            _status[cell] = 2;
            _lifetime[cell] = _max_lifetime;
        }
    }

    void setFood(int cell){
        if((0 <= cell) &&  (cell <= (_size_x*_size_y))){
            _status[cell] = 3;
        }
    }

    void resizeGrid(int Nx, int Ny){
        // Sets size of grid to given size.
        _size_x = Nx;
        _size_y = Ny;
        _clear();
    }

    void reset(){
        // FEHLT.
        _clear();
    }


    // --- Public Getters ---

    void print(){
        // Prints the grid on console.
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;

        for (int i = 0; i < _size_x * _size_y; i++) {
            if(i == 0) {
                std::cout << ". ";
            }
            if (i % _size_x == 0 && i>0) {
                std::cout << "." << std::endl << ". ";
            }

            switch (_status[i]){
                case 0: std::cout << "  "; break;
                case 1: std::cout << "O "; break;
                case 2: std::cout << "X "; break;
                case 3: std::cout << "* "; break;
            }
        }
        std::cout << "." << std::endl;
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;
    }


private:
    // --- Private Variables ---

    int _size_x;
    int _size_y;
    int _max_lifetime;

    enum Position {LOWER, UPPER, LEFT, RIGHT};

    int *_status;
    Position *_direction;
    int *_lifetime;


    // --- Private Setters ---




    // --- Private Getters ---

    int _getLower(int x_coord, int y_coord){
        // Returns cell value (position in 1D array) of the lower element.
        return _coordToCell(x_coord, y_coord+1);
    }

    int _getUpper(int x_coord, int y_coord){
        // Returns cell value (position in 1D array) of the upper element.
        return _coordToCell(x_coord, y_coord-1);
    }

    int _getLeft(int x_coord, int y_coord){
        // Returns cell value (position in 1D array) of the left element.
        return _coordToCell(x_coord-1, y_coord);
    }

    int _getRight(int x_coord, int y_coord){
        // Returns cell value (position in 1D array) of the right element.
        return _coordToCell(x_coord+1, y_coord);
    }

    int _coordToCell(int x, int y){
        // Converts coordinates of an element to the position in
        // 1-D array (called 'cell').
        return (y * _size_x + x);
    }




    // --- Private Setters ---

    void _clear(){
        // Clears arrays status, direction, lifetime.
        for (int i = 0; i < (_size_x * _size_y); i++){
                _status[i] = 0;
                _lifetime[i] = 0;
        }
    }

};
#endif // SNAKE_H
