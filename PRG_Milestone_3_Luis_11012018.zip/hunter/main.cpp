#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <conio.h>
#include <stdlib.h>
#include "Hunter.h"


int main() {

    Hunter hunter(10,10, 10);

    hunter.setHunted(44);

/*
    hunter.setFood(34);
    hunter.setFood(54);
    hunter.setFood(43);
    hunter.setFood(45);
*/

    hunter.setFood(54);
    hunter.setFood(64);



    hunter.print();
    hunter.WorldEvolutionLifePredator();
    hunter.print();



       int i = 0;
/*
    // Loop for running game
    while(i < 2){
        i++;

        // delay for better vizualisation
        _sleep(500);

        // remove old grid in console
        system("CLS");

        // evolve grid
        hunter.WorldEvolutionLifePredator();

        // prints grid
        hunter.print();
    }
*/


    // destroy instance of Snake
    hunter.~Hunter();

    // keep console window open
    system("PAUSE");
    return 0;
}
