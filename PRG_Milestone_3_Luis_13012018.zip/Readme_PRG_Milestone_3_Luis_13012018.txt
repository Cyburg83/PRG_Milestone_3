#################################
#	Vorl�ufige Readme..	#
#################################

Version: 	PRG_Milestone_3_Luis_13012018
Datum:		13.11.2018
Uhrzeit:	17:00 Uhr

-- Erkl�rung --
Als Nachbarzellen von O z�hlen die vier X. Es gibt also maximal vier Nachbarn:

  X
 XOX
  X

-- Bekannte Probleme --
- Verhalten der Zellen am Rand des Universums muss noch eingef�gt werden
- Wenn J�ger Nachbarn haben (1-3), aber diese nur Futter sind, bleibt der J�ger stehen. Eventuell sollte er auch auf eine freie Zelle wechseln (falls vorhanden)
- Wenn J�ger 4 Nachbarn haben, (also eingekesselt sind) kommt es zu Fehlern (h�ngt mit vorherigem Stichpunkt zusammen)