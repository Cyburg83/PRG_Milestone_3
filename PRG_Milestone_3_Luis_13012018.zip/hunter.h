#ifndef SNAKE_H
#define SNAKE_H

class Hunter{

public:
    Hunter(int Nx, int Ny, int max_lifetime){
        /* - Nx and Ny for grid size
         * - dynamic integer arrays for cell status, cell direction, cell lifetime
         * - (Cell status: 0 -> empty, 1 -> hunter, 2 -> hunted, 3 -> food)*/
        _size_x = Nx;
        _size_y = Ny;
        _max_lifetime = max_lifetime;

        _status = new int[_size_x*_size_y];
        _direction = new Position[_size_x*_size_y];
        _lifetime = new int[_size_x*_size_y];

        _clear();
    }

    ~Hunter(){
        delete [] _status;
        delete [] _direction;
        delete [] _lifetime;
    }


    // --- Public Setters ---

    void CellEvolutionDirection(int cell){
        // calculates cell direction for next evolutionary step.
        // HILFE
        std::cout << "-- Zelle Nr. " << cell << ":" << std::endl;


        // check if cell is alive (hunter or hunted)
        if (_status[cell] == 1 || _status[cell] == 2){

            // HILFE
            std::cout << "Zelle Nr. " << cell << " ist lebendig!" << std::endl;



                // check if cell has neighbors (hunter, hunted, food)
                if (_status[cell + _size_x] || _status[cell - _size_x] || _status[cell - 1] || _status[cell + 1]){

                    // HILFE
                    std::cout << "Zelle Nr. " << cell << " hat Nachbarn!" << std::endl;

                    // check if hunter
                    if (_status[cell] == 1){

                        // HILFE
                        std::cout << "Zelle Nr. " << cell << " ist Jaeger!" << std::endl;

                        // check if hunteds are nearby
                        int number_of_hunteds_nearby = 0;

                        Position nearby_hunteds[4];

                        // check lower cell
                        if (_status[cell + _size_x] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = LOWER;
                            number_of_hunteds_nearby++;
                        }
                        // check upper cell
                        if (_status[cell - _size_x] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = UPPER;
                            number_of_hunteds_nearby++;
                        }
                        // check left cell
                        if (_status[cell - 1] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = LEFT;
                            number_of_hunteds_nearby++;
                        }
                        // check right cell
                        if (_status[cell + 1] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = RIGHT;
                            number_of_hunteds_nearby++;
                        }

                        srand(time(NULL));
                        int random_neighbor = rand() % number_of_hunteds_nearby;

                        Position choosen_neighbor = nearby_hunteds[random_neighbor];

                        switch(choosen_neighbor){
                            // hunt lower hunted
                            case LOWER: _direction[cell] = LOWER; break;
                            // hunt upper hunted
                            case UPPER: _direction[cell] = UPPER; break;
                            // hunt left hunted
                            case LEFT: _direction[cell] = LEFT; break;
                            // hunt right hunted
                            case RIGHT: _direction[cell] = RIGHT; break;
                        }

                    }
                    // check if hunted
                    else if (_status[cell] == 2){

                        // HILFE
                        std::cout << "Zelle" << cell << "ist Gejagter!" << std::endl;

                        // check if hunter is not nearby
                        if (!((_status[cell + _size_x] == 1) || (_status[cell - _size_x] == 1) || (_status[cell - 1] == 1)|| (_status[cell + 1] == 1))){

                            // HILFE
                            std::cout << "Kein Jaeger daneben! Suche Futter!" << std::endl;

                            // check if food is nearby
                            int number_of_food = 0;

                            Position food[4];

                            // check lower cell
                            if (_status[cell + _size_x] == 3){
                                food[number_of_food] = LOWER;
                                number_of_food++;

                                // HILFE
                                std::cout << "Pruefe unteren Nachbarn!" << std::endl;
                            }
                            // check upper cell
                            if (_status[cell - _size_x] == 3){
                                food[number_of_food] = UPPER;
                                number_of_food++;

                                // HILFE
                                std::cout << "Pruefe oberen Nachbarn!" << std::endl;
                            }
                            // check left cell
                            if (_status[cell - 1] == 3){
                                food[number_of_food] = LEFT;
                                number_of_food++;

                                // HILFE
                                std::cout << "Pruefe linken Nachbarn!" << std::endl;
                            }
                            // check right cell
                            if (_status[cell + 1] == 3){
                                food[number_of_food] = RIGHT;
                                number_of_food++;

                                // HILFE
                                std::cout << "Pruefe rechten Nachbarn!" << std::endl;
                            }

                            // if food was found
                            if (number_of_food > 0){

                                // HILFE
                                std::cout << "Mind. ein Futter ist Nachbar!" << std::endl;
                                srand(time(NULL));
                                int random_food = rand() % number_of_food;

                                Position choosen_food = food[random_food];

                                switch(choosen_food){
                                    case LOWER: _direction[cell] = LOWER;
                                    // HILFE
                                    std::cout << "Versuche unteren zu fressen!" << std::endl;
                                    break;
                                    case UPPER: _direction[cell] = UPPER;
                                    // HILFE
                                    std::cout << "Versuche oberen zu fressen!" << std::endl;
                                    break;
                                    case LEFT: _direction[cell] = LEFT;
                                    // HILFE
                                    std::cout << "Versuche linken zu fressen!" << std::endl;
                                    break;
                                    case RIGHT: _direction[cell] = RIGHT;
                                    // HILFE
                                    std::cout << "Versuche rechten zu fressen!" << std::endl;
                                    break;
                                }
                            }
                        }
                    }
                }
                else{ // move cell randomly if it has no neighbors

                    // HILFE
                    std::cout << "Keine Nachbarn. Suche zufälligen Weg!" << std::endl;
                    srand(time(NULL));
                    Position random_position = Position(rand()%4);

                    switch(random_position){
                        case LOWER: _direction[cell] = LOWER; break;
                        case UPPER: _direction[cell] = UPPER; break;
                        case LEFT: _direction[cell] = LEFT; break;
                        case RIGHT: _direction[cell] = RIGHT; break;
                    }

                }
        }
    }


    void CellEvolutionMove(int cell){
        /* Prueft die vier umliegenden Zellen der gegebenen Koordinate
         * - Wenn sich eine umliegende Zelle zur gegebenen Koordinate bewegen will, bewege sie
         * - Wenn sich mehrere umliegende Zellen zur gegebenen Koordinate bewegen wollen, wähle
         *   zufällig eine aus.
         */

        // HILFE
        std::cout << "Cell EvolutionMove fuer Zelle Nr. " << cell << std::endl;

        // decrease lifetime if cell is alive
        if ((_status[cell] == 1) || (_status[cell] == 2)){
            _lifetime[cell]--; // decrement lifetime

            // kills cell
            if(_lifetime[cell] <= 0){
                // HILFE
                std::cout << "Zelle stirbt!" << std::endl;
                _status[cell] = 0;
                _lifetime[cell] = 0;
            }    
        }

        // check status of cell
        if(_status[cell] == 0){ // Case 0: Cell is dead
            int number_of_alive_cells_which_want_go_to_free_cell = 0;

            Position alive_cells_which_want_go_to_free_cell[4];

            // check if lower cell is hunter or hunted
            if ((_status[cell + _size_x] == 1) || (_status[cell + _size_x] == 2)){
                if(_direction[cell + _size_x] == UPPER){
                    alive_cells_which_want_go_to_free_cell[number_of_alive_cells_which_want_go_to_free_cell]=LOWER;
                    number_of_alive_cells_which_want_go_to_free_cell++;
                }
            }
            // check if upper cell is hunter or hunted
            if ((_status[cell - _size_x] == 1) || (_status[cell - _size_x] == 2)){
                if(_direction[cell - _size_x] == LOWER){
                    alive_cells_which_want_go_to_free_cell[number_of_alive_cells_which_want_go_to_free_cell]=UPPER;
                    number_of_alive_cells_which_want_go_to_free_cell++;
                }
            }
            // check if left cell is hunter or hunted
            if ((_status[cell - 1] == 1) || (_status[cell - 1] == 2)){
                if(_direction[cell - 1] == RIGHT){
                    alive_cells_which_want_go_to_free_cell[number_of_alive_cells_which_want_go_to_free_cell]=LEFT;
                    number_of_alive_cells_which_want_go_to_free_cell++;
                }
            }
            // check if right cell is hunter or hunted
            if ((_status[cell + 1] == 1) || (_status[cell + 1] == 2)){
                if(_direction[cell + 1] == LEFT){
                    alive_cells_which_want_go_to_free_cell[number_of_alive_cells_which_want_go_to_free_cell]=RIGHT;
                    number_of_alive_cells_which_want_go_to_free_cell++;
                }
            }

            if (number_of_alive_cells_which_want_go_to_free_cell > 0){
                // HILFE
                std::cout << "Mindestens ein Nachbar von " << cell << " möchte auf seine Position wechseln!" << std::endl;

                // chose an alive cell randomly which goes to the free cell
                srand(time(NULL));
                Position switching_cell = alive_cells_which_want_go_to_free_cell[rand() % number_of_alive_cells_which_want_go_to_free_cell];

                switch(switching_cell){
                case LOWER:
                    // HILFE
                    std::cout << "Untere lebendige Zelle geht nach " << cell << std::endl;
                    _status[cell]=_status[cell+_size_x];
                    _lifetime[cell]=_lifetime[cell+_size_x];
                    _direction[cell]= NONE;

                    _status[cell+_size_x]=0;
                    _lifetime[cell+_size_x]=0;
                    _direction[cell+_size_x]= NONE;
                break;
                case UPPER:
                    // HILFE
                    std::cout << "Obere lebendige Zelle geht nach " << cell << std::endl;
                    _status[cell]=_status[cell-_size_x];
                    _lifetime[cell]=_lifetime[cell-_size_x];
                    _direction[cell]= NONE;

                    _status[cell-_size_x]=0;
                    _lifetime[cell-_size_x]=0;
                    _direction[cell-_size_x]= NONE;
                break;
                case LEFT:
                    // HILFE
                    std::cout << "Linke lebendige Zelle geht nach " << cell << std::endl;
                    _status[cell]=_status[cell-1];
                    _lifetime[cell]=_lifetime[cell-1];
                    _direction[cell]= NONE;

                    _status[cell-1]=0;
                    _lifetime[cell-1]=0;
                    _direction[cell-1]= NONE;
                break;
                case RIGHT:
                    // HILFE
                    std::cout << "Rechte lebendige Zelle geht nach " << cell << std::endl;
                    _status[cell]=_status[cell+1];
                    _lifetime[cell]=_lifetime[cell+1];
                    _direction[cell]= NONE;

                    _status[cell+1]=0;
                    _lifetime[cell+1]=0;
                    _direction[cell+1]= NONE;
                break;
                }
            }
        }
        // Case 1: Cell is hunter
        else if (_status[cell] == 1) {
            // Nothing to do, because hunters can not be attacked
        }
        // Case 2: Cell is hunted
        else if (_status[cell] == 2) {
            // HILFE
            std::cout << "Zelle Nr. " << cell << " ist Gejagter und checkt umliegende Zellen nach Angreifern!" << std::endl;

            int number_of_hunters_which_want_hunted = 0;

            Position hunters_which_want_hunted[4];

            // check if lower cell is hunter and want to eat current cell
            if (_status[cell + _size_x] == 1){
                // HILFE
                std::cout << "Untere Zelle von " << cell << " ist Jaeger!" << std::endl;

                if(_direction[cell + _size_x] == UPPER){
                    // HILFE
                    std::cout << "und möchte Zelle über sich fressen!" << std::endl;
                    hunters_which_want_hunted[number_of_hunters_which_want_hunted]=LOWER;
                    number_of_hunters_which_want_hunted++;
                }
            }
            // check if upper cell is hunter and want to eat current cell
            if (_status[cell - _size_x] == 1){
                // HILFE
                std::cout << "Obere Zelle von " << cell << " ist Jaeger!" << std::endl;

                if(_direction[cell - _size_x] == LOWER){
                    hunters_which_want_hunted[number_of_hunters_which_want_hunted]=UPPER;
                    number_of_hunters_which_want_hunted++;
                }
            }
            // check if left cell is hunter and want to eat current cell
            if (_status[cell - 1] == 1){
                // HILFE
                std::cout << "Linke Zelle von " << cell << " ist Jaeger!" << std::endl;

                if(_direction[cell - 1] == RIGHT){
                    hunters_which_want_hunted[number_of_hunters_which_want_hunted]=LEFT;
                    number_of_hunters_which_want_hunted++;
                }
            }
            // check if right cell is hunter and want to eat current cell
            if (_status[cell + 1] == 1){
                // HILFE
                std::cout << "Rechte Zelle von " << cell << " ist Jaeger!" << std::endl;

                if(_direction[cell + 1] == LEFT){
                    hunters_which_want_hunted[number_of_hunters_which_want_hunted]=RIGHT;
                    number_of_hunters_which_want_hunted++;
                }
            }

            if (number_of_hunters_which_want_hunted > 0){
                // HILFE
                std::cout << "Mindestens ein Nachbar von " << cell << " möchte es fressen!" << std::endl;

                // chose a hunter randomly which eats the food
                srand(time(NULL));
                Position eating_hunter = hunters_which_want_hunted[rand() % number_of_hunters_which_want_hunted];

                switch(eating_hunter){
                    case LOWER:
                    // HILFE
                    std::cout << "Gejagter in Zelle " << cell << " wird von unterem Jaeger gefressen!" << std::endl;
                        _status[cell]=1;
                        _lifetime[cell]=_max_lifetime;
                        _direction[cell]= NONE;

                        _status[cell+_size_x]=0;
                        _lifetime[cell+_size_x]=0;
                        _direction[cell+_size_x]= NONE;
                    break;
                    case UPPER:
                    // HILFE
                    std::cout << "Gejagter in Zelle " << cell << " wird von oberem Jaeger gefressen!" << std::endl;
                        _status[cell]=1;
                        _lifetime[cell]=_max_lifetime;
                        _direction[cell]= NONE;

                        _status[cell-_size_x]=0;
                        _lifetime[cell-_size_x]=0;
                        _direction[cell-_size_x]= NONE;
                    break;
                    case LEFT:
                    // HILFE
                    std::cout << "Gejagter in Zelle " << cell << " wird von linkem Jaeger gefressen!" << std::endl;
                        _status[cell]=1;
                        _lifetime[cell]=_max_lifetime;
                        _direction[cell]= NONE;

                        _status[cell-1]=0;
                        _lifetime[cell-1]=0;
                        _direction[cell-1]= NONE;
                    break;
                    case RIGHT:
                    // HILFE
                    std::cout << "Gejagter in Zelle " << cell << " wird von rechtem Jaeger gefressen!" << std::endl;
                        _status[cell]=1;
                        _lifetime[cell]=_max_lifetime;
                        _direction[cell]= NONE;

                        _status[cell+1]=0;
                        _lifetime[cell+1]=0;
                        _direction[cell+1]= NONE;
                    break;
                }
            }
        }
        // Case 3: Cell is food
        else if (_status[cell] == 3) {
            // HILFE
            std::cout << "Zelle Nr. " << cell << " ist Futter!" << std::endl;

            int number_of_hunteds_which_want_food = 0;

            Position hunteds_which_want_food[4];

            // check if lower cell is hunted and want to eat current cell
            if (_status[cell + _size_x] == 2){
                // HILFE
                std::cout << "Untere Zelle von " << cell << " ist Gejagter!" << std::endl;

                if(_direction[cell + _size_x] == UPPER){
                    // HILFE
                    std::cout << "und möchte Zelle über sich fressen!" << std::endl;
                    hunteds_which_want_food[number_of_hunteds_which_want_food]=LOWER;
                    number_of_hunteds_which_want_food++;
                }
            }
            // check if upper cell is hunted and want to eat current cell
            if (_status[cell - _size_x] == 2){
                // HILFE
                std::cout << "Obere Zelle von " << cell << " ist Gejagter!" << std::endl;

                if(_direction[cell - _size_x] == LOWER){
                    hunteds_which_want_food[number_of_hunteds_which_want_food]=UPPER;
                    number_of_hunteds_which_want_food++;
                }
            }
            // check if left cell is hunted and want to eat current cell
            if (_status[cell - 1] == 2){
                // HILFE
                std::cout << "Linke Zelle von " << cell << " ist Gejagter!" << std::endl;

                if(_direction[cell - 1] == RIGHT){
                    hunteds_which_want_food[number_of_hunteds_which_want_food]=LEFT;
                    number_of_hunteds_which_want_food++;
                }
            }
            // check if right cell is hunted and want to eat current cell
            if (_status[cell + 1] == 2){
                // HILFE
                std::cout << "Rechte Zelle von " << cell << " ist Gejagter!" << std::endl;

                if(_direction[cell + 1] == LEFT){
                    hunteds_which_want_food[number_of_hunteds_which_want_food]=RIGHT;
                    number_of_hunteds_which_want_food++;
                }
            }

            if (number_of_hunteds_which_want_food > 0){
                // HILFE
                std::cout << "Mindestens ein Nachbar von " << cell << " möchte es fressen!" << std::endl;

                srand(time(NULL));
                Position eating_hunted = hunteds_which_want_food[rand() % number_of_hunteds_which_want_food];

                switch(eating_hunted){
                        case LOWER:
                        // HILFE
                        std::cout << "Futter in Zelle " << cell << " wird von unterem Gejagten gefressen!" << std::endl;
                            _status[cell]=2;
                            _lifetime[cell]=_max_lifetime;

                            _status[cell+_size_x]=0;
                            _lifetime[cell+_size_x]=0;
                        break;
                        case UPPER:
                        // HILFE
                        std::cout << "Futter in Zelle " << cell << " wird von oberem Gejagten gefressen!" << std::endl;
                            _status[cell]=2;
                            _lifetime[cell]=_max_lifetime;

                            _status[cell-_size_x]=0;
                            _lifetime[cell-_size_x]=0;
                        break;
                        case LEFT:
                        // HILFE
                        std::cout << "Futter in Zelle " << cell << " wird von linkem Gejagten gefressen!" << std::endl;
                            _status[cell]=2;
                            _lifetime[cell]=_max_lifetime;

                            _status[cell-1]=0;
                            _lifetime[cell-1]=0;
                        break;
                        case RIGHT:
                        // HILFE
                        std::cout << "Futter in Zelle " << cell << " wird von rechtem Gejagten gefressen!" << std::endl;
                            _status[cell]=2;
                            _lifetime[cell]=_max_lifetime;

                            _status[cell+1]=0;
                            _lifetime[cell+1]=0;
                        break;
                }
            }
        }
    }



    void WorldEvolutionLifePredator(){
        /* Executes the evolutionary step and updates the three arrays.
         */
        for(int i = 0; i < _size_x * _size_y; i++){
            CellEvolutionDirection(i); 
        }
        for(int i = 0; i < _size_x * _size_y; i++){
            CellEvolutionMove(i);
        }
    }

    void setMaxLifetime(int lifetime){
        /* Set the maximum lifetime for alive cells.
         */
        _max_lifetime = lifetime;
    }

    void setHunter(int cell){
        /* Places hunter on given position.
         */
        if((0 <= cell) &&  (cell <= (_size_x*_size_y))){
            _status[cell] = 1;
            _lifetime[cell] = _max_lifetime;
        }
    }

    void setHunted(int cell){
        /* Places hunted on given position.
         */
        if((0 <= cell) &&  (cell <= (_size_x*_size_y))){
            _status[cell] = 2;
            _lifetime[cell] = _max_lifetime;
        }
    }

    void setFood(int cell){
        /* Places food on given position.
         */
        if((0 <= cell) &&  (cell <= (_size_x*_size_y))){
            _status[cell] = 3;
        }
    }

    void resizeGrid(int Nx, int Ny){
        /* Changes grid size to the given horizontal and vertical length.
         */
        _size_x = Nx;
        _size_y = Ny;
        _clear();
    }

    void reset(){
        /* Clears the arrays.
         */
        _clear();
    }


    // --- Public Getters ---

    void print(){
        // Prints the grid on console.
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;

        for (int i = 0; i < _size_x * _size_y; i++) {
            if(i == 0) {
                std::cout << ". ";
            }
            if (i % _size_x == 0 && i>0) {
                std::cout << "." << std::endl << ". ";
            }

            switch (_status[i]){
                case 0: std::cout << "  "; break;
                case 1: std::cout << "O "; break;
                case 2: std::cout << "X "; break;
                case 3: std::cout << "* "; break;
            }
        }
        std::cout << "." << std::endl;
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;
    }


private:
    // --- Private Variables ---

    int _size_x;
    int _size_y;
    int _max_lifetime;

    enum Position {LOWER, UPPER, LEFT, RIGHT, NONE};

    int *_status;
    Position *_direction;
    int *_lifetime;

    // --- Private Setters ---

    void _clear(){
        /* Clears arrays status, direction, lifetime.
         */
        for (int i = 0; i < (_size_x * _size_y); i++){
                _status[i] = 0;
                _direction[i] = NONE;
                _lifetime[i] = 0;
        }
    }

};
#endif // SNAKE_H
