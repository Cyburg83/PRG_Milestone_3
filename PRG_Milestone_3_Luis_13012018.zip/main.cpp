#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <conio.h>
#include <stdlib.h>
#include "Hunter.h"


int main() {
// test run in console:
    // create new instance of 'Hunter'
    Hunter hunter(10,10, 10);

    // set hunters
    hunter.setHunter(44);

    // Set hunteds
    hunter.setHunted(34);
    hunter.setHunted(54);
    hunter.setHunted(43);
    hunter.setHunted(45);

    // set food
//    hunter.setFood(34);
//    hunter.setFood(90);
//    hunter.setFood(43);
//    hunter.setFood(45);

    // print grid before first evolutionary step
    hunter.print();

    // loop for running game
    int i = 0;
    while(i < 1 ){ // 1 evolutionary step
        i++;

        // delay for better vizualisation
        _sleep(500);

        // remove old grid in console
        //system("CLS");

        // evolve grid
        hunter.WorldEvolutionLifePredator();

        // prints grid
        hunter.print();
    }

    // destroy instance of 'Hunter'
    hunter.~Hunter();

    // keep console window open
    system("PAUSE");
    return 0;
}
