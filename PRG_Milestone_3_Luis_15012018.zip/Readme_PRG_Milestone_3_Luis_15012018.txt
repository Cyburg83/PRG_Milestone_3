#################################
#	Vorl�ufige Readme..	#
#################################

Version: 	PRG_Milestone_3_Luis_15012018
Datum:		15.11.2018
Uhrzeit:	16:00 Uhr

-- Erkl�rung --
Als Nachbarzellen von O z�hlen die vier X. Es gibt also maximal vier Nachbarn:

  X
 XOX
  X

-- Bekannte Probleme --
- keine
- Wenn J�ger Nachbarn haben (1-3), aber diese nur Futter sind, bleibt der J�ger stehen. Eventuell sollte er auch auf eine freie Zelle wechseln (falls vorhanden)


-- Behobene Probleme --
- Verhalten der Zellen am Rand des Universums muss noch eingef�gt werden
- Wenn J�ger 4 Nachbarn haben, (also eingekesselt sind) kommt es zu Fehlern


-- Anmerkung --
- Die Implementierung ist streng nach Aufgabenblatt
- Die beiden Hauptfunktionen "CellEvolutionDirection" und "CellEvolutionMove" haben keine Unterfunktionen und sind sehr gro�, 
  dass k�nnte ich noch �ndern. Mir ist es aber f�rs Erste auf diese Weise leichter gefallen.