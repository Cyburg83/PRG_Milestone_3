#ifndef SNAKE_H
#define SNAKE_H

class Hunter{

public:
    Hunter(int Nx, int Ny, int max_lifetime){
        /* - Nx and Ny for grid size
         * - dynamic integer arrays for cell status, cell direction, cell lifetime
         * - (Cell status: 0 -> empty, 1 -> hunter, 2 -> hunted, 3 -> food)*/
        _size_x = Nx;
        _size_y = Ny;
        _max_lifetime = max_lifetime;

        _status = new int[_size_x*_size_y];
        _direction = new Position[_size_x*_size_y];
        _lifetime = new int[_size_x*_size_y];

        _clear();
    }

    ~Hunter(){
//        delete [] _status;
//        delete [] _direction;
//        delete [] _lifetime;
    }


    // --- Public Setters ---

    void CellEvolutionDirection(int cell){
        // calculates cell direction for next evolutionary step.

        // check if cell is alive (hunter or hunted)
        if (_status[cell] == 1 || _status[cell] == 2){

            // check if cell is close to a border
            if ((cell >= ((_size_x*_size_y)-_size_x)) || (cell < _size_x) || (cell % _size_x == 0) || ((cell+1) % _size_x == 0)){

                // close to lower border
                if (cell >= ((_size_x*_size_y)-_size_x)){
                    _direction[cell]=UPPER;
                }
                // close to upper border
                else if (cell < _size_x){
                    _direction[cell]=LOWER;
                }
                // close to left border
                else if (cell % _size_x == 0){
                    _direction[cell]=RIGHT;
                }
                // close to right border
                else if ((cell+1) % _size_x == 0){
                    _direction[cell]=LEFT;
                }

            }else{
                // check if cell has neighbors (hunter, hunted, food)
                if (_status[cell + _size_x] || _status[cell - _size_x] || _status[cell - 1] || _status[cell + 1]){

                    // check if hunter
                    if (_status[cell] == 1){

                        // check if hunteds are nearby
                        int number_of_hunteds_nearby = 0;

                        Position nearby_hunteds[4];

                        // check lower cell
                        if (_status[cell + _size_x] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = LOWER;
                            number_of_hunteds_nearby++;
                        }
                        // check upper cell
                        if (_status[cell - _size_x] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = UPPER;
                            number_of_hunteds_nearby++;
                        }
                        // check left cell
                        if (_status[cell - 1] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = LEFT;
                            number_of_hunteds_nearby++;
                        }
                        // check right cell
                        if (_status[cell + 1] == 2){
                            nearby_hunteds[number_of_hunteds_nearby] = RIGHT;
                            number_of_hunteds_nearby++;
                        }

                        // if hunteds were found
                        if(number_of_hunteds_nearby > 0){
                            srand(time(NULL));
                            int random_neighbor = rand() % number_of_hunteds_nearby;

                            Position choosen_neighbor = nearby_hunteds[random_neighbor];

                            switch(choosen_neighbor){
                                // hunt lower hunted
                                case LOWER: _direction[cell] = LOWER; break;
                                // hunt upper hunted
                                case UPPER: _direction[cell] = UPPER; break;
                                // hunt left hunted
                                case LEFT: _direction[cell] = LEFT; break;
                                // hunt right hunted
                                case RIGHT: _direction[cell] = RIGHT; break;
                            }
                        }

                    }
                    // check if hunted
                    else if (_status[cell] == 2){

                        // check if hunter is not nearby
                        if (!((_status[cell + _size_x] == 1) || (_status[cell - _size_x] == 1) || (_status[cell - 1] == 1)|| (_status[cell + 1] == 1))){

                            // check if food is nearby
                            int number_of_food = 0;

                            Position food[4];

                            // check lower cell
                            if (_status[cell + _size_x] == 3){
                                food[number_of_food] = LOWER;
                                number_of_food++;
                            }

                            // check upper cell
                            if (_status[cell - _size_x] == 3){
                                food[number_of_food] = UPPER;
                                number_of_food++;
                            }

                            // check left cell
                            if (_status[cell - 1] == 3){
                                food[number_of_food] = LEFT;
                                number_of_food++;
                            }

                            // check right cell
                            if (_status[cell + 1] == 3){
                                food[number_of_food] = RIGHT;
                                number_of_food++;
                            }

                            // if food was found
                            if (number_of_food > 0){

                                srand(time(NULL));
                                int random_food = rand() % number_of_food;

                                Position choosen_food = food[random_food];

                                switch(choosen_food){
                                    case LOWER: _direction[cell] = LOWER; break;
                                    case UPPER: _direction[cell] = UPPER; break;
                                    case LEFT: _direction[cell] = LEFT; break;
                                    case RIGHT: _direction[cell] = RIGHT; break;
                                }
                            }
                        }
                    }
                }
                else{ // move cell randomly if it has no neighbors

                    srand(time(NULL));
                    Position random_position = Position(rand()%4);

                    switch(random_position){
                        case LOWER: _direction[cell] = LOWER; break;
                        case UPPER: _direction[cell] = UPPER; break;
                        case LEFT: _direction[cell] = LEFT; break;
                        case RIGHT: _direction[cell] = RIGHT; break;
                    }

                    // behavior on the borders
                    // lower border
                    if((cell >= ((_size_x * _size_y) - _size_x)) && (cell < (_size_x * _size_y)) && (random_position == LOWER)){
                        random_position = UPPER;
                    }
                    // upper border
                    if((cell < _size_x) && (random_position == UPPER)){
                        random_position = LOWER;
                    }
                    // left border
                    if(((cell % _size_x) == 0) && (random_position == LEFT)){
                        random_position = RIGHT;
                    }
                    // right border
                    if(((cell+1) % _size_x == 0) && (random_position == RIGHT)){
                        random_position = LEFT;
                    }

                }
            }
        }
    }


    void CellEvolutionMove(int cell){
        /* Prueft die vier umliegenden Zellen der gegebenen Koordinate
         * - Wenn sich eine umliegende Zelle zur gegebenen Koordinate bewegen will, bewege sie
         * - Wenn sich mehrere umliegende Zellen zur gegebenen Koordinate bewegen wollen, wähle
         *   zufällig eine aus.
         */

        // check status of cell
        if(_status[cell] == 0){ // Case 0: Cell is dead
            int number_of_alive_cells_which_want_go_to_free_cell = 0;

            Position alive_cells_which_want_go_to_free_cell[4];

            // check if lower cell is hunter or hunted
            //if (!((cell < _size_x * _size_y) && (cell >= ((_size_x * _size_y)-_size_x)))){ // check if cell is not close to lower border
                if ((_status[cell + _size_x] == 1) || (_status[cell + _size_x] == 2)){
                    if(_direction[cell + _size_x] == UPPER){
                        alive_cells_which_want_go_to_free_cell[number_of_alive_cells_which_want_go_to_free_cell]=LOWER;
                        number_of_alive_cells_which_want_go_to_free_cell++;
                    }
                }
            //}
            // check if upper cell is hunter or hunted
            //if(!(cell < _size_x)){ // check if cell is not close to upper border
                if ((_status[cell - _size_x] == 1) || (_status[cell - _size_x] == 2)){
                    if(_direction[cell - _size_x] == LOWER){
                        alive_cells_which_want_go_to_free_cell[number_of_alive_cells_which_want_go_to_free_cell]=UPPER;
                        number_of_alive_cells_which_want_go_to_free_cell++;
                    }
                }
            //}
            // check if left cell is hunter or hunted
            //if (!(cell % _size_x == 0)){ // check if cell is not close to left border
                if ((_status[cell - 1] == 1) || (_status[cell - 1] == 2)){
                    if(_direction[cell - 1] == RIGHT){
                        alive_cells_which_want_go_to_free_cell[number_of_alive_cells_which_want_go_to_free_cell]=LEFT;
                        number_of_alive_cells_which_want_go_to_free_cell++;
                    }
                }
            //}
            // check if right cell is hunter or hunted
            //if (!(((cell % _size_x)+1) % _size_x == 0)){ // check if cell is not close to right border
                if ((_status[cell + 1] == 1) || (_status[cell + 1] == 2)){
                    if(_direction[cell + 1] == LEFT){
                        alive_cells_which_want_go_to_free_cell[number_of_alive_cells_which_want_go_to_free_cell]=RIGHT;
                        number_of_alive_cells_which_want_go_to_free_cell++;
                    }
                }
            //}

            if (number_of_alive_cells_which_want_go_to_free_cell > 0){

                // chose an alive cell randomly which goes to the free cell
                srand(time(NULL));
                Position switching_cell = alive_cells_which_want_go_to_free_cell[rand() % number_of_alive_cells_which_want_go_to_free_cell];

                switch(switching_cell){
                case LOWER:
                    _status[cell]=_status[cell+_size_x];
                    _lifetime[cell]=_lifetime[cell+_size_x];
                    _direction[cell]= NONE;

                    _status[cell+_size_x]=0;
                    _lifetime[cell+_size_x]=0;
                    _direction[cell+_size_x]= NONE;
                break;
                case UPPER:
                    _status[cell]=_status[cell-_size_x];
                    _lifetime[cell]=_lifetime[cell-_size_x];
                    _direction[cell]= NONE;

                    _status[cell-_size_x]=0;
                    _lifetime[cell-_size_x]=0;
                    _direction[cell-_size_x]= NONE;
                break;
                case LEFT:
                    _status[cell]=_status[cell-1];
                    _lifetime[cell]=_lifetime[cell-1];
                    _direction[cell]= NONE;

                    _status[cell-1]=0;
                    _lifetime[cell-1]=0;
                    _direction[cell-1]= NONE;
                break;
                case RIGHT:
                    _status[cell]=_status[cell+1];
                    _lifetime[cell]=_lifetime[cell+1];
                    _direction[cell]= NONE;

                    _status[cell+1]=0;
                    _lifetime[cell+1]=0;
                    _direction[cell+1]= NONE;
                break;
                }
            }
        }
        // Case 1: Cell is hunter
        else if (_status[cell] == 1) {

            // if lifetime is null then kill
            if ((_lifetime[cell] == 0) || (_lifetime[cell] < 0)){
                _status[cell] = 0;
                _lifetime[cell] = 0;
                _direction[cell] = NONE;
            }else{
                // decrease lifetime
                _lifetime[cell]--;
            }

        }
        // Case 2: Cell is hunted
        else if (_status[cell] == 2) {
            // if lifetime is null then kill
            if ((_lifetime[cell] == 0) || (_lifetime[cell] < 0)){
                _status[cell] = 0;
                _lifetime[cell] = 0;
                _direction[cell] = NONE;
            }else{

                int number_of_hunters_which_want_hunted = 0;

                Position hunters_which_want_hunted[4];

                // check if lower cell is hunter and want to eat current cell
                if (_status[cell + _size_x] == 1){
                    if(_direction[cell + _size_x] == UPPER){
                        hunters_which_want_hunted[number_of_hunters_which_want_hunted]=LOWER;
                        number_of_hunters_which_want_hunted++;
                    }
                }
                // check if upper cell is hunter and want to eat current cell
                if (_status[cell - _size_x] == 1){
                    if(_direction[cell - _size_x] == LOWER){
                        hunters_which_want_hunted[number_of_hunters_which_want_hunted]=UPPER;
                        number_of_hunters_which_want_hunted++;
                    }
                }
                // check if left cell is hunter and want to eat current cell
                if (_status[cell - 1] == 1){
                    if(_direction[cell - 1] == RIGHT){
                        hunters_which_want_hunted[number_of_hunters_which_want_hunted]=LEFT;
                        number_of_hunters_which_want_hunted++;
                    }
                }
                // check if right cell is hunter and want to eat current cell
                if (_status[cell + 1] == 1){
                    if(_direction[cell + 1] == LEFT){
                        hunters_which_want_hunted[number_of_hunters_which_want_hunted]=RIGHT;
                        number_of_hunters_which_want_hunted++;
                    }
                }

                if (number_of_hunters_which_want_hunted > 0){
                    // chose a hunter randomly which eats the food
                    srand(time(NULL));
                    Position eating_hunter = hunters_which_want_hunted[rand() % number_of_hunters_which_want_hunted];

                    switch(eating_hunter){
                        case LOWER:
                            _status[cell]=1;
                            _lifetime[cell]=_max_lifetime;
                            _direction[cell]= NONE;

                            _status[cell+_size_x]=0;
                            _lifetime[cell+_size_x]=0;
                            _direction[cell+_size_x]= NONE;
                        break;
                        case UPPER:
                            _status[cell]=1;
                            _lifetime[cell]=_max_lifetime;
                            _direction[cell]= NONE;

                            _status[cell-_size_x]=0;
                            _lifetime[cell-_size_x]=0;
                            _direction[cell-_size_x]= NONE;
                        break;
                        case LEFT:
                            _status[cell]=1;
                            _lifetime[cell]=_max_lifetime;
                            _direction[cell]= NONE;

                            _status[cell-1]=0;
                            _lifetime[cell-1]=0;
                            _direction[cell-1]= NONE;
                        break;
                        case RIGHT:
                            _status[cell]=1;
                            _lifetime[cell]=_max_lifetime;
                            _direction[cell]= NONE;

                            _status[cell+1]=0;
                            _lifetime[cell+1]=0;
                            _direction[cell+1]= NONE;
                        break;
                    }
                }
            // decrement lifetime
            _lifetime[cell]--;
            }
        }
        // Case 3: Cell is food
        else if (_status[cell] == 3) {

            int number_of_hunteds_which_want_food = 0;

            Position hunteds_which_want_food[4];

            // check if lower cell is hunted and want to eat current cell
            if (_status[cell + _size_x] == 2){
                if(_direction[cell + _size_x] == UPPER){
                    hunteds_which_want_food[number_of_hunteds_which_want_food]=LOWER;
                    number_of_hunteds_which_want_food++;
                }
            }
            // check if upper cell is hunted and want to eat current cell
            if (_status[cell - _size_x] == 2){
                if(_direction[cell - _size_x] == LOWER){
                    hunteds_which_want_food[number_of_hunteds_which_want_food]=UPPER;
                    number_of_hunteds_which_want_food++;
                }
            }
            // check if left cell is hunted and want to eat current cell
            if (_status[cell - 1] == 2){
                if(_direction[cell - 1] == RIGHT){
                    hunteds_which_want_food[number_of_hunteds_which_want_food]=LEFT;
                    number_of_hunteds_which_want_food++;
                }
            }
            // check if right cell is hunted and want to eat current cell
            if (_status[cell + 1] == 2){
                if(_direction[cell + 1] == LEFT){
                    hunteds_which_want_food[number_of_hunteds_which_want_food]=RIGHT;
                    number_of_hunteds_which_want_food++;
                }
            }

            if (number_of_hunteds_which_want_food > 0){

                srand(time(NULL));
                Position eating_hunted = hunteds_which_want_food[rand() % number_of_hunteds_which_want_food];

                switch(eating_hunted){
                        case LOWER:
                            _status[cell]=2;
                            _lifetime[cell]=_max_lifetime;

                            _status[cell+_size_x]=0;
                            _lifetime[cell+_size_x]=0;
                        break;
                        case UPPER:
                            _status[cell]=2;
                            _lifetime[cell]=_max_lifetime;

                            _status[cell-_size_x]=0;
                            _lifetime[cell-_size_x]=0;
                        break;
                        case LEFT:
                            _status[cell]=2;
                            _lifetime[cell]=_max_lifetime;

                            _status[cell-1]=0;
                            _lifetime[cell-1]=0;
                        break;
                        case RIGHT:
                            _status[cell]=2;
                            _lifetime[cell]=_max_lifetime;

                            _status[cell+1]=0;
                            _lifetime[cell+1]=0;
                        break;
                }
            }
        }
    }



    void WorldEvolutionLifePredator(){
        /* Executes the evolutionary step and updates the three arrays.
         */
        for(int i = 0; i < _size_x * _size_y; i++){
            CellEvolutionDirection(i); 
        }
        for(int i = 0; i < _size_x * _size_y; i++){
            CellEvolutionMove(i);
        }
    }

    void setMaxLifetime(int lifetime){
        /* Set the maximum lifetime for alive cells.
         */
        _max_lifetime = lifetime;
    }

    void setHunter(int cell){
        /* Places hunter on given position.
         */
        if((0 <= cell) &&  (cell <= (_size_x*_size_y))){
            _status[cell] = 1;
            _lifetime[cell] = _max_lifetime;
        }
    }

    void setHunted(int cell){
        /* Places hunted on given position.
         */
        if((0 <= cell) &&  (cell <= (_size_x*_size_y))){
            _status[cell] = 2;
            _lifetime[cell] = _max_lifetime;
        }
    }

    void setFood(int cell){
        /* Places food on given position.
         */
        if((0 <= cell) &&  (cell <= (_size_x*_size_y))){
            _status[cell] = 3;
        }
    }

    void resizeGrid(int Nx, int Ny){
        /* Changes grid size to the given horizontal and vertical length.
         */
        _size_x = Nx;
        _size_y = Ny;
        _clear();
    }

    void reset(){
        /* Clears the arrays.
         */
        _clear();
    }


    // --- Public Getters ---

    void print(){
        // Prints the grid on console.
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;

        for (int i = 0; i < _size_x * _size_y; i++) {
            if(i == 0) {
                std::cout << ". ";
            }
            if (i % _size_x == 0 && i>0) {
                std::cout << "." << std::endl << ". ";
            }

            switch (_status[i]){
                case 0: std::cout << "  "; break;
                case 1: std::cout << "O "; break;
                case 2: std::cout << "X "; break;
                case 3: std::cout << "* "; break;
            }
        }
        std::cout << "." << std::endl;
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;
    }


private:
    // --- Private Variables ---

    int _size_x;
    int _size_y;
    int _max_lifetime;

    enum Position {LOWER, UPPER, LEFT, RIGHT, NONE};

    int *_status;
    Position *_direction;
    int *_lifetime;


    // --- Private Setters ---

    void _clear(){
        /* Clears arrays status, direction, lifetime.
         */
        for (int i = 0; i < (_size_x * _size_y); i++){
                _status[i] = 0;
                _direction[i] = NONE;
                _lifetime[i] = 0;
        }
    }

};
#endif // SNAKE_H
