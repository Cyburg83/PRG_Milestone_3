#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <conio.h>
#include <stdlib.h>
#include "Hunter.h"


int main() {
// test run in console:
    // create new instance of 'Hunter'
    Hunter hunter(5, 5, 10);


    // set hunters
    hunter.setHunter(0);
//    hunter.setHunter(76);
//    hunter.setHunter(77);
//    hunter.setHunter(78);
//    hunter.setHunter(95);
//    hunter.setHunter(125);
//    hunter.setHunter(178);
//    hunter.setHunter(244);


    // Set hunteds
    hunter.setHunted(14);
    hunter.setHunted(16);
    hunter.setHunted(3);
    hunter.setHunted(9);

    // set food
    hunter.setFood(15);
    hunter.setFood(2);
//    hunter.setFood(51);
//    hunter.setFood(41);
//    hunter.setFood(31);

    // print grid before first evolutionary step
    hunter.print();

    // loop for running game
    int i = 0;
    while(i < 40 ){ // 1 evolutionary step
        i++;

        // delay for better vizualisation
        _sleep(500);

        // remove old grid in console
        system("CLS");

        // evolve grid
        hunter.WorldEvolutionLifePredator();

        // prints grid
        hunter.print();
    }

    // destroy instance of 'Hunter'
    hunter.~Hunter();

    // keep console window open
    system("PAUSE");
    return 0;
}
